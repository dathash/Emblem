# Emblem
Alex Hartford

A small turn-based strategy game in the vein of Fire Emblem.

A learning project in Modern C++, including:
- Smart Pointers
- Command Pattern
- OO (lite) design
- As many pure functions as I can reasonably fit

Credit to Bob Nystrom for the book Game Programming Patterns, 
Ocornut for the <em>ImGui</em>,
SDL People for the <em>SDL</em>,
and to the folks on <em>The Spriter's Resource</em> for the sprites.
