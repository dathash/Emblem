# Hiring Log
# Summer 2022
# Alex Hartford

 Plan
======
Build a fun little game!

 Log
=====
> June 30 | 6h  | 500 lines   | Start
> July 1  | 10h | 1500 		  | Stayed up till 3 working on Command system. Very excited!
> July 2  | 8h	| 2100		  | Finished most of basic commands.
> July 3  | 9h  | 3000		  | Added most command functionality. Added tweens and animated sprites. Also some User Interface!
> July 4  | 1h  | 3100		  | Didn't have much time today. Just added some little tweaks and started on combat.
> July 7  | 3h  | 3300		  | Finished level loading system. Pretty happy with such quick work.
> July 8  | 6h  | 3100		  | Dropped tween system, added some rudimentary AI.
> July 9  | 3h  | 3300		  | Finished rudimentary AI.

> Total	  | 46h


 Notes
=======
